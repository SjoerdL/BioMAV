package nl.ru.ai.projects.parrot.dronecontrol;

public interface ParrotDroneInterface extends ControlInterface, VideoPollInterface, SensoryDataInterface {

}
